package scalatorch.ffm

import java.lang.foreign.{Arena, FunctionDescriptor, Linker, MemoryLayout, MemorySegment, SymbolLookup}
import java.lang.foreign.ValueLayout.{ADDRESS, JAVA_FLOAT, JAVA_INT, JAVA_LONG}
import scala.util.Using

/** Internal, thread-confined driver session. Resources release in reverse acquisition order. */
private[ffm] final class CudaDriver private (
    val arena: Arena, register: (() => Unit) => Unit
):
  private val lookup = SymbolLookup.libraryLookup(CudaDriver.libraryName, arena)
  private val linker = Linker.nativeLinker()
  // Downcall handles are built once per (symbol, signature). Building one per call cost more than the kernel launch it wrapped:
  // a U-Net pass makes about a thousand driver calls.
  private val handles = new java.util.concurrent.ConcurrentHashMap[(String, Seq[MemoryLayout]), java.lang.invoke.MethodHandle]()
  private def handleFor(name: String, layouts: Seq[MemoryLayout]): java.lang.invoke.MethodHandle =
    val key = (name, layouts)
    val known = handles.get(key)
    if known != null then known
    else
      val symbol = lookup.find(name).orElseThrow(() => UnsatisfiedLinkError(s"CUDA symbol missing: $name"))
      val created = linker.downcallHandle(symbol, FunctionDescriptor.of(JAVA_INT, layouts*))
      handles.put(key, created)
      created
  private def result(name: String, layouts: Seq[MemoryLayout], args: AnyRef*): Int =
    handleFor(name, layouts).invokeWithArguments(args*).asInstanceOf[Integer].intValue()
  private val launchLayouts: Seq[MemoryLayout] = Seq(ADDRESS) ++ Seq.fill(7)(JAVA_INT) ++ Seq.fill(3)(ADDRESS)
  private lazy val launchHandle = handleFor("cuLaunchKernel", launchLayouts)
  private val syncLayouts: Seq[MemoryLayout] = Seq(ADDRESS)
  private lazy val syncHandle = handleFor("cuStreamSynchronize", syncLayouts)
  private val ctxGetLayouts: Seq[MemoryLayout] = Seq(ADDRESS)
  private lazy val ctxGetHandle = handleFor("cuCtxGetCurrent", ctxGetLayouts)
  /** Current CUDA context pointer read into caller-owned 8-byte segment, without Arena allocation. */
  def currentContext(cell: MemorySegment): Long =
    val code: Int = ctxGetHandle.invokeExact(cell)
    if code != 0 then throw IllegalStateException(s"cuCtxGetCurrent failed with CUDA status $code")
    cell.get(ADDRESS, 0).address()
  /** One-dimensional kernel launch on `stream`, without boxing or a signature lookup. */
  def launchKernel(kernel: MemorySegment, blocks: Int, threadsPerBlock: Int, stream: MemorySegment, params: MemorySegment): Unit =
    val code: Int = launchHandle.invokeExact(kernel, blocks, 1, 1, threadsPerBlock, 1, 1, 0, stream, params, MemorySegment.NULL)
    if code != 0 then throw IllegalStateException(s"cuLaunchKernel failed with CUDA status $code")
  /** Generalized 3D grid/block kernel launch with dynamic shared memory on `stream`. */
  def launchKernel3D(kernel: MemorySegment, gx: Int, gy: Int, gz: Int, bx: Int, by: Int, bz: Int, sharedBytes: Int, stream: MemorySegment, params: MemorySegment): Unit =
    val code: Int = launchHandle.invokeExact(kernel, gx, gy, gz, bx, by, bz, sharedBytes, stream, params, MemorySegment.NULL)
    if code != 0 then throw IllegalStateException(s"cuLaunchKernel failed with CUDA status $code")
  def synchronize(stream: MemorySegment): Unit =
    val code: Int = syncHandle.invokeExact(stream)
    if code != 0 then throw IllegalStateException(s"cuStreamSynchronize failed with CUDA status $code")
  private val memcpyDtoDLayouts: Seq[MemoryLayout] = Seq(JAVA_LONG, JAVA_LONG, JAVA_LONG, ADDRESS)
  private lazy val memcpyDtoDHandle = handleFor("cuMemcpyDtoDAsync_v2", memcpyDtoDLayouts)
  def copyDeviceToDevice(dst: Long, src: Long, bytes: Long, stream: MemorySegment): Unit =
    if bytes > 0L then
      val code: Int = memcpyDtoDHandle.invokeExact(dst, src, bytes, stream)
      if code != 0 then throw IllegalStateException(s"cuMemcpyDtoDAsync_v2 failed with CUDA status $code")
  def call(name: String, layouts: Seq[MemoryLayout], args: AnyRef*): Unit =
    val code=result(name,layouts,args*)
    if code != 0 then throw IllegalStateException(s"$name failed with CUDA status $code")
  def loadModule(ptx: String): MemorySegment =
    val output=arena.allocate(ADDRESS)
    val options=arena.allocate(2L*JAVA_INT.byteSize(),JAVA_INT.byteAlignment())
    options.setAtIndex(JAVA_INT,0,5) // CU_JIT_ERROR_LOG_BUFFER
    options.setAtIndex(JAVA_INT,1,6) // CU_JIT_ERROR_LOG_BUFFER_SIZE_BYTES
    val errorLog=arena.allocate(8192,1)
    val errorLogSize=arena.allocate(JAVA_INT)
    errorLogSize.set(JAVA_INT,0,8192)
    val values=arena.allocate(2L*ADDRESS.byteSize(),ADDRESS.byteAlignment())
    values.setAtIndex(ADDRESS,0,errorLog)
    values.setAtIndex(ADDRESS,1,errorLogSize)
    val image=arena.allocateFrom(ptx)
    val code=result("cuModuleLoadDataEx",Seq(ADDRESS,ADDRESS,JAVA_INT,ADDRESS,ADDRESS),
      output,image,Int.box(2),options,values)
    if code != 0 then
      val detail=errorLog.getString(0)
      throw IllegalStateException(s"cuModuleLoadDataEx failed with CUDA status $code${if detail.nonEmpty then s": $detail" else ""}")
    output.get(ADDRESS,0)
  def cleanup(action: => Unit): Unit = register(() => action)
  def pointerResult(name: String, layouts: Seq[MemoryLayout], args: AnyRef*): MemorySegment =
    val pointer = arena.allocate(ADDRESS)
    call(name, ADDRESS +: layouts, (pointer +: args)*)
    pointer.get(ADDRESS, 0L)
  def allocateDevice(bytes: Long): Long =
    val pointer = arena.allocate(JAVA_LONG)
    call("cuMemAlloc_v2", Seq(ADDRESS, JAVA_LONG), pointer, Long.box(math.max(bytes, 1L)))
    val address = pointer.get(JAVA_LONG, 0L)
    cleanup { call("cuMemFree_v2", Seq(JAVA_LONG), Long.box(address)) }
    address
  private lazy val infoCells=(arena.allocate(JAVA_LONG),arena.allocate(JAVA_LONG))
  private val infoLayouts: Seq[MemoryLayout] = Seq(ADDRESS, ADDRESS)
  private lazy val infoHandle = handleFor("cuMemGetInfo_v2", infoLayouts)
  /** Free device memory in bytes as the driver reports it now. */
  def freeBytes(): Long =
    val code: Int = infoHandle.invokeExact(infoCells._1, infoCells._2)
    if code != 0 then throw IllegalStateException(s"cuMemGetInfo_v2 failed with CUDA status $code")
    infoCells._1.get(JAVA_LONG, 0L)
  def memoryInfo(): (Long,Long) =
    val free=arena.allocate(JAVA_LONG)
    val total=arena.allocate(JAVA_LONG)
    call("cuMemGetInfo_v2",Seq(ADDRESS,ADDRESS),free,total)
    val available=free.get(JAVA_LONG,0L)
    val capacity=total.get(JAVA_LONG,0L)
    require(available>=0 && capacity>0 && available<=capacity,"CUDA returned invalid device memory information")
    (available,capacity)
  def upload(values: Array[Float]): Long =
    val address = allocateDevice(values.length.toLong * 4)
    if values.nonEmpty then
      val host = arena.allocateFrom(JAVA_FLOAT, values*)
      copyHostToDevice(address,host,values.length.toLong*4)
    address
  /** Pageable synchronous HtoD may return before DMA completes on the default stream.
    * Complete that transfer before a nonblocking compute stream can consume it.
    */
  def copyHostToDevice(address: Long,host: MemorySegment,bytes: Long): Unit =
    call("cuMemcpyHtoD_v2",Seq(JAVA_LONG,ADDRESS,JAVA_LONG),Long.box(address),host,Long.box(bytes))
    call("cuStreamSynchronize",Seq(ADDRESS),MemorySegment.NULL)
  private[ffm] def copyHostToDeviceProfiled(address: Long,host: MemorySegment,bytes: Long)
      (record: (String,Long) => Unit): Unit =
    var started=System.nanoTime()
    call("cuMemcpyHtoD_v2",Seq(JAVA_LONG,ADDRESS,JAVA_LONG),Long.box(address),host,Long.box(bytes))
    record("HtoD call",System.nanoTime()-started)
    started=System.nanoTime()
    call("cuStreamSynchronize",Seq(ADDRESS),MemorySegment.NULL)
    record("HtoD stream sync",System.nanoTime()-started)
  def download(address: Long, count: Int): Array[Float] =
    val out = arena.allocate(count.toLong * 4, 4)
    if count > 0 then call("cuMemcpyDtoH_v2", Seq(ADDRESS, JAVA_LONG, JAVA_LONG), out, Long.box(address), Long.box(count.toLong * 4))
    out.toArray(JAVA_FLOAT)

private[ffm] object CudaDriver:
  private def libraryName: String =
    val os = System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT)
    require(ADDRESS.byteSize() == 8, "CUDA requires a 64-bit JVM")
    if os.startsWith("windows") then "nvcuda.dll"
    else if os == "linux" then "libcuda.so.1"
    else throw IllegalArgumentException(s"CUDA requires Windows or Linux, got $os")

  def withDevice[A](index: Int)(body: (CudaDriver, Int, String) => A): A =
    require(index >= 0, "negative device index")
    Using.Manager { use =>
      val arena = use(Arena.ofConfined())
      val driver = new CudaDriver(arena, action => {
        use(new AutoCloseable { def close(): Unit = action() }); ()
      })
      import driver.*
      call("cuInit", Seq(JAVA_INT), Int.box(0))
      val version = arena.allocate(JAVA_INT)
      call("cuDriverGetVersion", Seq(ADDRESS), version)
      val device = arena.allocate(JAVA_INT)
      call("cuDeviceGet", Seq(ADDRESS, JAVA_INT), device, Int.box(index))
      val dev = device.get(JAVA_INT, 0L)
      val name = arena.allocate(256)
      call("cuDeviceGetName", Seq(ADDRESS, JAVA_INT, JAVA_INT), name, Int.box(256), Int.box(dev))
      val previous = pointerResult("cuCtxGetCurrent", Seq.empty)
      val context = pointerResult("cuDevicePrimaryCtxRetain", Seq(JAVA_INT), Int.box(dev))
      cleanup { call("cuDevicePrimaryCtxRelease_v2", Seq(JAVA_INT), Int.box(dev)) }
      CudaContextKeeper.enter(dev)
      cleanup { CudaContextKeeper.exit(dev) }
      call("cuCtxSetCurrent", Seq(ADDRESS), context)
      cleanup { call("cuCtxSetCurrent", Seq(ADDRESS), previous) }
      body(driver, version.get(JAVA_INT, 0L), name.getString(0L))
    }.get
/** Keeps the CUDA primary context (and the cuBLAS handles created on it) alive between back-to-back sessions. A generation opens several
  * sessions (text encoder, U-Net, VAE); creating and destroying the context costs about 90 ms and the cuBLAS handle about 150 ms each time.
  * Once no session has been open for `SCALATORCH_CUDA_KEEP_CONTEXT_SECONDS` (default 60, 0 = never keep) the handles and the extra context
  * reference are dropped, so the device memory of the context is returned when no generation is running. */
private[ffm] object CudaContextKeeper:
  val seconds: Long = sys.env.get("SCALATORCH_CUDA_KEEP_CONTEXT_SECONDS").flatMap(_.trim.toLongOption).getOrElse(60L)
  def enabled: Boolean = seconds > 0
  private final class State(var context: MemorySegment, var active: Int, var lastExit: Long, val closers: java.util.ArrayList[() => Unit])
  private val states = new java.util.HashMap[Int, State]()
  private val scheduler = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { r =>
    val t = new Thread(r, "scala-torch-cuda-context-keeper"); t.setDaemon(true); t
  }
  private lazy val handles: (java.lang.invoke.MethodHandle, java.lang.invoke.MethodHandle, java.lang.invoke.MethodHandle, java.lang.invoke.MethodHandle) =
    val os = System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT)
    val lookup = SymbolLookup.libraryLookup(if os.startsWith("windows") then "nvcuda.dll" else "libcuda.so.1", Arena.global())
    val linker = Linker.nativeLinker()
    def find(symbol: String, d: FunctionDescriptor) = linker.downcallHandle(lookup.find(symbol).orElseThrow(), d)
    (find("cuDevicePrimaryCtxRetain", FunctionDescriptor.of(JAVA_INT, ADDRESS, JAVA_INT)),
      find("cuDevicePrimaryCtxRelease_v2", FunctionDescriptor.of(JAVA_INT, JAVA_INT)),
      find("cuCtxSetCurrent", FunctionDescriptor.of(JAVA_INT, ADDRESS)),
      find("cuMemFree_v2", FunctionDescriptor.of(JAVA_INT, JAVA_LONG)))

  /** Frees device memory; only valid from a closer registered with [[onRelease]] (the context is current there). */
  def freeMemory(address: Long): Unit = try handles._4.invokeWithArguments(Long.box(address)) catch case _: Throwable => ()

  /** Releases everything kept for `device` (shared weights, cuBLAS handles, the extra context reference) unless a session is open on it. */
  def clearDevice(device: Int): Unit = release(device,force=true)

  /** A session starts on `device` (its own context reference is already taken): make sure our extra reference exists. */
  def enter(device: Int): Unit =
    if !enabled then return
    try states.synchronized {
      val st = states.get(device) match
        case null =>
          val created = new State(MemorySegment.NULL, 0, System.nanoTime(), new java.util.ArrayList[() => Unit]())
          states.put(device, created); created
        case existing => existing
      if st.context == MemorySegment.NULL then
        Using.resource(Arena.ofConfined()) { arena =>
          val out = arena.allocate(ADDRESS)
          if handles._1.invokeWithArguments(out, Int.box(device)).asInstanceOf[Integer].intValue() == 0 then st.context = out.get(ADDRESS, 0L)
        }
      st.active += 1
    } catch case _: Throwable => ()

  def exit(device: Int): Unit =
    if !enabled then return
    try states.synchronized {
      val st = states.get(device)
      if st != null then
        st.active = math.max(0, st.active - 1)
        st.lastExit = System.nanoTime()
        scheduler.schedule(new Runnable { def run(): Unit = release(device) }, seconds, java.util.concurrent.TimeUnit.SECONDS)
    } catch case _: Throwable => ()

  /** Registers a resource that lives on the kept context (for example a cuBLAS handle); closed before the context is released. */
  def onRelease(device: Int, closer: () => Unit): Unit =
    states.synchronized { val st = states.get(device); if st != null then st.closers.add(closer) else closer() }

  private def release(device: Int, force: Boolean = false): Unit =
    states.synchronized {
      val st = states.get(device)
      if st != null && st.active == 0 && st.context != MemorySegment.NULL &&
          (force || System.nanoTime() - st.lastExit >= seconds * 1_000_000_000L - 100_000_000L) then
        try
          handles._3.invokeWithArguments(st.context)
          st.closers.forEach(c => try c() catch case _: Throwable => ())
          st.closers.clear()
          handles._3.invokeWithArguments(MemorySegment.NULL)
        catch case _: Throwable => ()
        try handles._2.invokeWithArguments(Int.box(device)) catch case _: Throwable => ()
        st.context = MemorySegment.NULL
    }
