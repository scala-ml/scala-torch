package scalatorch.models

import scalatorch.*
import scalatorch.nn.*
import java.io.{BufferedInputStream,BufferedOutputStream,DataInputStream,DataOutputStream,IOException,OutputStream}
import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.{Files,Path,StandardCopyOption}
import java.security.{DigestOutputStream,MessageDigest}
import scala.util.Using

/** Full resident AdamW checkpoint: architecture binding around the existing checked state format. */
private[models] object BackendLlamaCheckpoint:
  private val magic="STBADM02".getBytes(UTF_8)
  private val legacyMagic="STBADM01".getBytes(UTF_8)
  private val headerBytes=52L
  private def binding(model: LlamaModel,context: String): Array[Byte] =
    require(context.length<=4096 && TokenizerJson.validUnicode(context),"invalid checkpoint context")
    val hash=MessageDigest.getInstance("SHA-256")
    Using.resource(new DataOutputStream(new DigestOutputStream(OutputStream.nullOutputStream(),hash))) { out =>
      val c=model.config
      Seq(c.vocabSize,c.hiddenSize,c.intermediateSize,c.numLayers,c.numAttentionHeads,c.numKeyValueHeads,c.maxPositions).foreach(out.writeInt)
      out.writeDouble(c.rmsNormEps);out.writeDouble(c.ropeTheta);out.writeBoolean(c.tieWordEmbeddings)
      out.writeBoolean(c.bosTokenId.nonEmpty);c.bosTokenId.foreach(out.writeLong)
      out.writeInt(c.eosTokenIds.size);c.eosTokenIds.foreach(out.writeLong);out.writeDouble(c.initializerRange)
      out.writeInt(model.layers.size)
      def projection(layer: Linear): Unit =
        out.writeBoolean(layer.bias.nonEmpty);out.writeBoolean(layer.lora.nonEmpty)
        layer.lora.foreach(a => out.writeDouble(a.alpha))
      model.layers.foreach { layer =>
        out.writeDouble(layer.inputNorm.epsilon);out.writeDouble(layer.postNorm.epsilon)
        Seq(layer.attention.qProj,layer.attention.kProj,layer.attention.vProj,layer.attention.oProj,
          layer.mlp.gateProj,layer.mlp.upProj,layer.mlp.downProj).foreach(projection)
      }
      out.writeDouble(model.norm.epsilon);projection(model.lmHead)
      // Empty context preserves the original architecture fingerprint byte-for-byte.
      if context.nonEmpty then
        val bytes=context.getBytes(UTF_8)
        out.writeInt(bytes.length);out.write(bytes)
    }
    hash.digest()
  def save(model: LlamaModel,weights: Map[String,Tensor[Float]],moments: Map[String,AdamWMoments],
      config: AdamWConfig,path: Path,step: Long,maxBytes: Long,context: String): Unit =
    require(maxBytes>=headerBytes,"invalid checkpoint byte budget")
    val fingerprint=binding(model,context)
    val contextBytes=context.getBytes(UTF_8)
    require(maxBytes>=headerBytes+contextBytes.length,"checkpoint byte budget exceeded")
    val destination=path.toAbsolutePath.normalize()
    Files.createDirectories(destination.getParent)
    val state=Files.createTempFile(destination.getParent,".backend-adam-state-",".tmp")
    try
      BackendAdamCheckpoint.save(model,weights,moments,config,state,step)
      val length=Files.size(state)
      require(length<=maxBytes-headerBytes-contextBytes.length,"checkpoint byte budget exceeded")
      val temporary=Files.createTempFile(destination.getParent,".backend-adam-bundle-",".tmp")
      try
        Using.resource(new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)))) { out =>
          out.write(magic);out.write(fingerprint);out.writeInt(contextBytes.length);out.write(contextBytes)
          out.writeLong(length);Files.copy(state,out)
        }
        Files.move(temporary,destination,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING)
      finally Files.deleteIfExists(temporary)
    finally Files.deleteIfExists(state)
  private final case class Header(fingerprint: Array[Byte],context: String,length: Long,size: Long)
  private def readHeader(in: DataInputStream,maxBytes: Long): Header =
    require(maxBytes>=48L,"invalid checkpoint byte budget")
    val version=in.readNBytes(8)
    val legacy=version.sameElements(legacyMagic)
    require(legacy || version.sameElements(magic),"unsupported backend checkpoint format")
    val fingerprint=in.readNBytes(32)
    require(fingerprint.length==32,"truncated checkpoint fingerprint")
    val contextSize=if legacy then 0 else in.readInt()
    require(contextSize>=0 && contextSize<=16384,"invalid checkpoint context size")
    val bytes=in.readNBytes(contextSize)
    require(bytes.length==contextSize,"truncated checkpoint context")
    val context=UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString
    require(context.length<=4096 && TokenizerJson.validUnicode(context),"invalid checkpoint context")
    val length=in.readLong()
    val header=(if legacy then 48L else headerBytes)+contextSize
    require(length>=0 && length<=maxBytes-header,"checkpoint byte budget exceeded")
    Header(fingerprint,context,length,header)

  /** Bounded metadata discovery only; restore verifies the model binding and complete payload. */
  def savedContext(path: Path,maxBytes: Long): String =
    try Using.resource(new DataInputStream(new BufferedInputStream(Files.newInputStream(path)))) { in =>
      val header=readHeader(in,maxBytes)
      require(Files.size(path)==header.size+header.length,"checkpoint size mismatch")
      header.context
    } catch case error: IOException => throw IllegalArgumentException("invalid or unreadable backend checkpoint",error)

  private def withPayload[A](model: LlamaModel,path: Path,maxBytes: Long,context: Option[String])(body: Path => A): A =
    require(maxBytes>=48L,"invalid checkpoint byte budget")
    val state=Files.createTempFile("backend-adam-load-",".tmp")
    try
      try Using.resource(new DataInputStream(new BufferedInputStream(Files.newInputStream(path)))) { in =>
        val header=readHeader(in,maxBytes)
        context.foreach(expected => require(expected==header.context,"checkpoint training context mismatch"))
        require(MessageDigest.isEqual(header.fingerprint,binding(model,header.context)),"checkpoint model configuration/context mismatch")
        Using.resource(new BufferedOutputStream(Files.newOutputStream(state))) { out =>
          val buffer=new Array[Byte](65536)
          var remaining=header.length
          while remaining>0 do
            val n=in.read(buffer,0,math.min(remaining,buffer.length.toLong).toInt)
            require(n>0,"truncated backend checkpoint")
            out.write(buffer,0,n);remaining-=n
        }
        require(in.read()== -1,"backend checkpoint has trailing bytes")
      }
      catch case error: IOException => throw IllegalArgumentException("invalid or unreadable backend checkpoint",error)
      body(state)
    finally Files.deleteIfExists(state)
  def load(model: LlamaModel,config: AdamWConfig,path: Path,maxBytes: Long,context: Option[String]): BackendAdamCheckpoint.Saved =
    withPayload(model,path,maxBytes,context)(state => BackendAdamCheckpoint.load(model,config,state))
  def loadWeights(model: LlamaModel,path: Path,maxBytes: Long,context: Option[String]): BackendAdamCheckpoint.Saved =
    withPayload(model,path,maxBytes,context)(state => BackendAdamCheckpoint.loadWeights(model,state))
