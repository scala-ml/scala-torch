package scalatorch.models

import scalatorch.*
import scalatorch.io.SafeTensorSet
import scalatorch.nn.*
import java.nio.file.Path
import scala.collection.mutable
import scala.util.Using

/** Diffusers single or indexed safetensors loader. Parameters are frozen unless requested. */
object PretrainedUNet:
  def load(directory: Path,trainable: Boolean=false,maxParameters: Long=1000000000L,
      maxScoreElements: Long=16777216L): ConditionalUNet2d =
    loadWithLinearTargets(directory,trainable,maxParameters,maxScoreElements).model

  def loadWithLinearTargets(directory: Path,trainable: Boolean=false,maxParameters: Long=1000000000L,
      maxScoreElements: Long=16777216L): LoadedLinearModel[ConditionalUNet2d] =
    require(maxParameters>=0 && maxScoreElements>=0,"negative U-Net parameter or attention budget")
    val c=UNetConfig.read(directory.resolve("config.json"))
    Using.resource(SafeTensorSet.open(directory,filename="diffusion_pytorch_model.safetensors")) { archive =>
      loadFromView(SingleFileTensorView(archive,archive.tensors.keysIterator.map(name => name -> name).toVector),
        c,trainable,maxParameters,maxScoreElements)
    }

  private[models] def loadSingleFile(archive: SafeTensorSet,trainable: Boolean=false,
      maxParameters: Long=1000000000L,maxScoreElements: Long=16777216L): LoadedLinearModel[ConditionalUNet2d] =
    val config = SingleFileSd1Config.unetConfigFor(archive)
    loadFromView(SingleFileTensorView.unet(archive),config,trainable,maxParameters,maxScoreElements)

  private[models] def loadSd1View(archive: SingleFileTensorView,config: UNetConfig,
      maxScoreElements: Long,maxParameters: Long=1000000000L): LoadedLinearModel[ConditionalUNet2d] =
    loadFromView(archive,config,false,maxParameters,maxScoreElements)

  private def loadFromView(archive: SingleFileTensorView,c: UNetConfig,trainable: Boolean,
      maxParameters: Long,maxScoreElements: Long): LoadedLinearModel[ConditionalUNet2d] =
    require(maxParameters>=0 && maxScoreElements>=0,"negative U-Net parameter or attention budget")
    locally {
      val total=archive.tensors.values.foldLeft(BigInt(0))((sum,t) => sum+t.shape.numel)
      require(total<=maxParameters,"U-Net weights exceed parameter budget")
      val used=mutable.Set.empty[String]
      val targets=mutable.Map.empty[String,Parameter]
      def parameter(name: String,dims: Int*): Parameter =
        val shape=Shape.from(dims.map(_.toLong))
        val info=archive.tensors.getOrElse(name,throw IllegalArgumentException(s"missing U-Net weight: $name"))
        require(info.shape==shape,s"U-Net weight shape mismatch: $name, expected $shape, got ${info.shape}")
        require(used.add(name),s"duplicate U-Net parameter use: $name")
        Parameter(archive.readFloat(name),trainable)
      def linear(name: String,in: Int,out: Int,bias: Boolean=true): Linear =
        val weight=parameter(s"$name.weight",out,in)
        targets(s"unet.$name")=weight
        Linear(weight,if bias then Some(parameter(s"$name.bias",out)) else None)
      def conv(name: String,in: Int,out: Int,k: Int=3,stride: Int=1,padding: Int=1): Conv2d =
        val weight=parameter(s"$name.weight",out,in,k,k)
        targets(s"unet.$name")=weight
        Conv2d(weight,Some(parameter(s"$name.bias",out)),
          Conv2dConfig(stride=(stride,stride),padding=(padding,padding)))
      def group(name: String,width: Int,epsilon: Double): GroupNorm =
        GroupNorm(c.groups,width,Some(parameter(s"$name.weight",width)),Some(parameter(s"$name.bias",width)),epsilon)
      def norm(name: String,width: Int): LayerNorm =
        LayerNorm(width,Some(parameter(s"$name.weight",width)),Some(parameter(s"$name.bias",width)),1e-5)
      def resnet(name: String,in: Int,out: Int,scale: Double=1): DiffusionResnet2d =
        DiffusionResnet2d(group(s"$name.norm1",in,c.epsilon),conv(s"$name.conv1",in,out),
          Some(linear(s"$name.time_emb_proj",c.timeWidth,out)),group(s"$name.norm2",out,c.epsilon),
          conv(s"$name.conv2",out,out),if in==out then None else Some(conv(s"$name.conv_shortcut",in,out,1,padding=0)),scale)
      def spatial(name: String,width: Int,stage: Int): DiffusionSpatialTransformer =
        def attention(prefix: String,context: Int): DiffusionAttention =
          DiffusionAttention(linear(s"$prefix.to_q",width,width,false),linear(s"$prefix.to_k",context,width,false),
            linear(s"$prefix.to_v",context,width,false),linear(s"$prefix.to_out.0",width,width),c.headsAt(stage),maxScoreElements)
        val blocks=Vector.tabulate(c.transformerLayersAt(stage)) { i =>
          val p=s"$name.transformer_blocks.$i"
          DiffusionTransformerBlock(norm(s"$p.norm1",width),attention(s"$p.attn1",width),
            norm(s"$p.norm2",width),attention(s"$p.attn2",c.contextWidth),norm(s"$p.norm3",width),
            DiffusionFeedForward(linear(s"$p.ff.net.0.proj",width,width*8),linear(s"$p.ff.net.2",width*4,width)))
        }
        def projection(prefix: String): Conv2d =
          if !c.linearProjection then conv(prefix,width,width,1,padding=0)
          else
            val flat=parameter(s"$prefix.weight",width,width)
            val weight=Parameter(flat.data.reshape(Shape.from(Seq(width.toLong,width.toLong,1L,1L))),trainable)
            targets(s"unet.$prefix")=weight
            Conv2d(weight,
              Some(parameter(s"$prefix.bias",width)),Conv2dConfig())
        DiffusionSpatialTransformer(group(s"$name.norm",width,1e-6),projection(s"$name.proj_in"),
          blocks,projection(s"$name.proj_out"))
      def layer(prefix: String,index: Int,in: Int,out: Int,attention: Boolean,stage: Int): DiffusionUNetLayer =
        DiffusionUNetLayer(resnet(s"$prefix.resnets.$index",in,out),
          if attention then Some(spatial(s"$prefix.attentions.$index",out,stage)) else None)
      val convIn=conv("conv_in",c.inChannels,c.channels.head)
      val time=DiffusionTimeEmbedding(linear("time_embedding.linear_1",c.channels.head,c.timeWidth),
        linear("time_embedding.linear_2",c.timeWidth,c.timeWidth))
      val addition=c.additionInputWidth.map(width => DiffusionTimeEmbedding(
        linear("add_embedding.linear_1",width,c.timeWidth),linear("add_embedding.linear_2",c.timeWidth,c.timeWidth)))
      var current=c.channels.head
      val skips=mutable.ArrayBuffer(current)
      val down=c.channels.indices.toVector.map { i =>
        val out=c.channels(i);val prefix=s"down_blocks.$i"
        val layers=Vector.tabulate(c.layersPerBlock) { j =>
          val l=layer(prefix,j,current,out,c.downAttention(i),i)
          current=out;skips+=out;l
        }
        val sample=if i==c.channels.size-1 then None else
          skips+=out
          Some(DiffusionDownsample2d(conv(s"$prefix.downsamplers.0.conv",out,out,stride=2,padding=c.downsamplePadding)))
        DiffusionDownBlock(layers,sample)
      }
      val mid=DiffusionMidBlock(resnet("mid_block.resnets.0",current,current,c.midScale),
        spatial("mid_block.attentions.0",current,c.channels.size-1),resnet("mid_block.resnets.1",current,current,c.midScale))
      val up=c.channels.reverse.zipWithIndex.map { (out,i) =>
        val prefix=s"up_blocks.$i"
        val layers=Vector.tabulate(c.layersPerBlock+1) { j =>
          val skip=skips.remove(skips.size-1)
          val l=layer(prefix,j,current+skip,out,c.upAttention(i),c.channels.size-1-i)
          current=out;l
        }
        val sample=if i==c.channels.size-1 then None else
          Some(DiffusionUpsample2d(conv(s"$prefix.upsamplers.0.conv",out,out)))
        DiffusionUpBlock(layers,sample)
      }
      val model=ConditionalUNet2d(convIn,time,down,mid,up,group("conv_norm_out",current,c.epsilon),
        conv("conv_out",current,c.outChannels),DiffusionTimeSettings(c.flipSinToCos,c.frequencyShift),addition,c.additionTimeWidth.getOrElse(0))
      require(used.toSet==archive.tensors.keySet,s"unused U-Net weights: ${(archive.tensors.keySet--used).toVector.sorted.mkString(", ")}")
      LoadedLinearModel(model,targets.toMap)
    }
